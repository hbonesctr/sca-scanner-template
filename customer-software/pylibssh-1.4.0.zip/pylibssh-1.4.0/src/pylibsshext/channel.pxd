# distutils: libraries = ssh
#
# This file is part of the ansible-pylibssh library
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, see file LICENSE.rst in this
# repository.
#
from pylibsshext.includes cimport callbacks, libssh


cdef class Channel:
    cdef  _session
    cdef libssh.ssh_channel _libssh_channel
    cdef libssh.ssh_session _libssh_session
    cdef _open_session_with_retries(self, libssh.ssh_channel test_channel)

cdef class ChannelCallback:
    cdef callbacks.ssh_channel_callbacks_struct callback
    cdef _userdata
